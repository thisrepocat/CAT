# 🐕 thisrepo/dog


Just a dog living in a git repository. 🦴

Solana token address: `HhWuCfTzdgx3Jam5wfe7mTgc6QxndnzExtLDZsDVpump`

<img src="https://github.com/user-attachments/assets/9ecb09c0-8050-4ce3-a827-dcf40bd0fac2" width="200" alt="DOG">

## 💬 Communication
All discussions take place in Issues - join the conversation there.

## 🔒 Pull Request Policy
Only top token holders will be able to merge future pull requests.

## Feed Me
🌟 1 star = 1 kibble.
