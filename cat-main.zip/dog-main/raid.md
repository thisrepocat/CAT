## This is an official raid board of ghdog

First step, go and click a rocket on DEX Screener: https://dexscreener.com/solana/3mepqkixq3ov9pbmyxbybhnfvztxrzneqtwbaehwpbvt

### Now, you know what to do on X/Twitter:

- https://x.com/sol_engineer/status/1852703033555116067
- https://x.com/MrMoon2016/status/1852705176718876971
- https://x.com/sol_engineer/status/1852721367751201029
- https://x.com/sprtpttlg/status/1852712955197988913
- https://x.com/binokrisvaldy/status/1852695251879878838
- https://x.com/binokrisvaldy/status/1852689691700805761
- https://x.com/sol_engineer/status/1852726948700508508
- https://x.com/grindzhard/status/1852726647448854552
- https://x.com/lilmutt32/status/1852718998280130767
- https://x.com/lilmutt32/status/1852737121028845625
- https://x.com/sol_engineer/status/1852732234932891810
